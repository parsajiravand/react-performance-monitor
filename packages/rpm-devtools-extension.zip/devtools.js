chrome.devtools.panels.create(
  "RPM",
  "",
  "panel-react.html",
  function(panel) {
    console.log("RPM DevTools panel created with React UI")
  }
)