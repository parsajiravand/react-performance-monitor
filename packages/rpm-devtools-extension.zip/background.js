// Background service worker to relay messages between content script and devtools panel
let connections = {}

chrome.runtime.onConnect.addListener((port) => {
  if (port.name === "rpm-devtools") {
    const tabId = port.sender.tab.id
    connections[tabId] = port

    port.onDisconnect.addListener(() => {
      delete connections[tabId]
    })

    port.onMessage.addListener((message) => {
      // Relay messages from panel to content script if needed
      console.log("DevTools panel message:", message)
    })
  }
})

// Relay messages from content script to devtools panel
chrome.runtime.onMessage.addListener((message, sender) => {
  const tabId = sender.tab.id
  if (connections[tabId]) {
    connections[tabId].postMessage(message)
  }
})