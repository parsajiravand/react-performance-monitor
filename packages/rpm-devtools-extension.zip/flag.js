// Flag script injected by RPM DevTools extension
// This runs in the page context to signal extension presence
window.__RPM_DEVTOOLS__ = true